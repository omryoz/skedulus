<?
	define("EZSQL_DB_USER", "root");			// <-- mysql db user
	define("EZSQL_DB_PASSWORD", "");		// <-- mysql db password
	define("EZSQL_DB_NAME", "skedulus");		// <-- mysql db pname
	define("EZSQL_DB_HOST", "localhost");	// <-- mysql server host
		 
?>