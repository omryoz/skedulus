
Web2CalLanguage_FR={
	 CLOSE: "Close"
	 ,DAYS:[ "Dimanche", "Lundi","Mardi","Mecredi", "Jeudi" , "Vendredi","Samedi"]
	 ,DAYS_SHORT: [ "Dim","Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"]
	 ,DAYS_SHORT2: [ "Di","Lu", "Ma", "Me", "Je", "Ve", "Sa"]
	 ,MONTHS_SHORT: ["Jan", "Fev","Mar", "Avr","Mai" ,"Jui", "Juil","Aou", "Sep","Oct","Nov","Dec"] 
	 ,MONTHS: ["Janvier", "Fevrier","Mars", "Avril","Mai" ,"Juin", "Juillet","Aout", "Septembre","Octobre","Novembre","Decembre"]
	,LABEL_MONTH: "Mois"
	,LABEL_WEEK: "Semaine" 
	,LABEL_RECUR_EDIT_WINDOW:"Edit Recurring Event"
	,LABEL_EDIT_RECUR_EVENT_DESC: "	Would you like to change only this event, all events, or this and all future events in the series?"
	,LABEL_IS_RECURRING_EVENT: "This is a recurring Event"
	,LABEL_DAY: "Jour"
	,LABEL_NEXT: "Après "
	,LABEL_W2CVIEW: "W2C View"
	,LABEL_AGENDA: "Ordre du jour"
	,LABEL_WORKSHIFT: "Workshift"
	,LABEL_DAYS: "Jours"
	,LABEL_WORKWEEK: "Semaine de travail"
	,LABEL_HIDESHOW: "cabillot" 
	,LABEL_AM: "AM"
	,LABEL_PM: "PM" 
	,LABEL_EVENTNAME: "Event Name"
	,LABEL_STARTDATE: "Start Date"
	,LABEL_STARTTIME: "Start Time"
	,LABEL_ENDDATE: "End Date"
	,LABEL_ENDTIME: "End Time"
	,LABEL_GROUP: "Group"
	,LABEL_ALLDAY: "All Day?"
	,LABEL_CREATEEVENT: "Créez l'événement"
	,LABEL_DESCRIPTION: "Description" 
	,LABEL_INFORMATION: "Information" 
	,LABEL_VIEWALL: "Voyez tous"
	,LABEL_DESCRIPTION: "Description"  
	,LABEL_NOTITLE: "No Title" 
	,LABEL_CREATENEWEVENT: "Créez le nouvel événement" 
	,LABEL_CREATENEW: "Créez nouveau" 
	,LABEL_OPTIONS: "Options" 
	,LABEL_FILTER: "Filter"  
	,LABEL_EXPAND_DETAILS: "Show All" 
	,LABEL_COLLAPSE_DETAILS: "Collapse All" 
	,LABEL_MORE: "Plus" 
	
	,MSG_LOADINGMSG: "Chargement... Attendez svp"  
	,MSG_RETRIEVING: "Recherche des événements" 
		
	,MSG_VIEW_NOTFOUND:"Vue '{0}' Non trouvé. \nVérifiez vos arrangements. La vue de défaut peut ne pas être dans les vues choisies"
}

