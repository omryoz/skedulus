<div class="navbar  navbar-inverse container">
		  <div class="navbar-inner">
			<a class="btn btn-navbar " data-toggle="collapse" data-target=".menu1">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			<div class="nav-collapse collapse menu1">			
				<ul class="nav client-navbar">
					<li class="">
						<a href="<?php echo base_url();?>cprofile"><center><i class="icon-home"></i><p>Home</p></center></a>
					</li>
					<li class="">
						<a href="<?php echo base_url();?>bcalendar/mycalender"><center><i class="icon-calendar"></i><p> My Appointments</p>
						</center></a>
					</li>
					<li class="">
						<a href="<?php echo base_url();?>clients/favourite"><center><i class="icon-star"></i><p> Favourite Businesses
						</p></center>
						</a>
					</li>
					<li class=""><a href="<?php echo base_url();?>clients/offers"><center><i class="icon-thumbs-up"></i><p>Special Offers
					</p></center>
						</a>
					</li>
					<li class="borderless"><a href="<?php echo base_url();?>clients/settings"><center><i class="icon-wrench"></i><p>Settings</p>
						</center></a>
					</li>
					
				</ul>
			</div>
		  </div>
		</div>


