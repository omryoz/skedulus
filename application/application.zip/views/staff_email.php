Hi <?php echo $name;?>,<br/>
Kindly login with the following credentials: <br/>
Email:&nbsp;<?php echo $email; ?> <br/>
Password:&nbsp;<?php echo $randomPassword; ?><br/>

Activation link : <br/>
<a href="<?php echo base_url(); ?>home/employee/?activation_link=<?php echo $activation_key ?>">
<?php echo base_url(); ?>home/employee/?activation_link=<?php echo $activation_key ?>
</a>


<br/><br/>
Regards,<br/>
Skedulus team.


