

				
			
			
			
		
			<br/>
<div class="content container">
	<div class="row-fluid business_profile">
		<div class="row-fluid left-nav">
			<div class="Wrap">
					 <div class="wrap_inner">
						
							<ul class="thumbnails business_logo">
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/1.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
							    <li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/2.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/3.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/4.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>		  
						    </ul>
					
					
						<ul class="thumbnails business_logo">
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/5.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
							    <li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/6.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/7.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/8.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>		  
						    </ul>
							<ul class="thumbnails business_logo">
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/9.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
							    <li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/10.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/11.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/12.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>		  
						    </ul>
							<ul class="thumbnails business_logo">
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/5.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
							    <li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/3.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/7.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>
								<li class="thumbnail span3 trans">
									<a href="business_profile.php">
										<img src="<?php echo base_url(); ?>images/9.jpg">
										<div class="caption">
											<p class="text-left"><strong>Sarah wilton</strong></p>
											<small> Hair Stylist </small>
										</div>
									</a>
								</li>		  
						    </ul>
					</div>
		  		</div>
		</div>
			
		</div>	
</div>		



