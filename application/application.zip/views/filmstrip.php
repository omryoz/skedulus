<div class="filmstrip">

	
	
	<ul class="thumbnails scroller image_popup">
		<?php for($i=1;$i<10;$i++){?>
			<li class="" >
			
				<a href="#" ><i class="icon-heart heart"></i></a><a href="#" ><i class="icon-comment comment "></i></a><a href="#theater_view" role="button"  data-toggle="modal"><img src="../images/3.jpg" alt="" ></a>
			</li>
		<?php } ?>
	</ul>

</div>
		