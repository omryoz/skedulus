Hi <?php echo $name;?>,<br/>
Please click <a href="<?php echo base_url(); ?>home/businesslogin/?activation_link=<?php echo $activation_key ?>" /> here </a> or on the following link to activate your account.<br/>
Activation link : <br/>
<a href="<?php echo base_url(); ?>home/businesslogin/?activation_link=<?php echo $activation_key ?>" /><?php echo base_url(); ?>home/businesslogin/?activation_link=<?php echo $activation_key ?></a>


<br/><br/>
Regards,<br/>
Skedulus team.


