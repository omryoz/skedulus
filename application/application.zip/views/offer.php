<?php //include('header_login.php')?>

<div class="content container">
	<div class="row-fluid business_profile">
			<div class="row-fluid">
				
				<div class="row-fluid Wrap">
						 <div class="wrap_inner">
					<h3>Search Businesses</h3>
						<div class="row-fluid strip">
							<div class="span4">
								<input type="text" class="span12 search_input" placeholder="Business Name">
							</div>
							<div class="span3">
								<input type="text" class="span12 search_input" placeholder="Location">	
							</div>
							<div class="span3">													
								<select class="span12">
										<option value="0">Categories</option>
										<option value="1">Hair Style</option>
										<option value="2">Boutique</option>
										<option value="3">Spa</option>
										<option value="4">Yoga classes</option>
								</select>	
							</div>
							<div class="span2">						
								 <a  href="#" class="btn span12 pull-right btn-success"> <i class="icon-search"></i> Search</a>
							</div>
						</div>
						<!--<div class="row-fluid strip">
							<div class="span2">
								<input type="text" class="span12 search_input" placeholder="Business Name">
							</div>
							<div class="span2">
								<input type="text" class="span12 search_input" placeholder="Best Value">
							</div>
							<div class="span2">
								<input type="text" class="span12 search_input" placeholder="Expiration Date">	
							</div>
							<div class="span2">													
								<select class="span12">
										<option value="0">Categories</option>
										<option value="1">Hair Style</option>
										<option value="2">Boutique</option>
										<option value="3">Spa</option>
										<option value="4">Yoga classes</option>
								</select>	
							</div>
							<div class="span2">						
								 <a  href="#" class="btn span12 pull-right btn-success"> <i class="icon-search"></i> Search</a>
							</div>
						</div>-->
					</div>
				</div>	
			</div>
		
			<div class="row-fluid offer_box">
			<div class="offer_box_inner">
				<div class="span3 ">
					<div class="thumbnail">
						<img src="<?php echo base_url();?>images/1.jpg">
						<div class="row-fluid">
							<div class="caption span12">
							<b class="text-left">Sarah wilton</b><br clear="left">
							<small> Hair Stylist </small>
							</div>
						</div>
					</div>
						
				</div>
				<div class="span3 offset1">
					<h3>20% <small>for hair cut</small> <br><b >Off</b> </h3><br/>
					<p>
						Lorem ipsum dolar sit amit,
						Lorem ipsum dolar sit amit,
					</p>
				</div>
				<div class="span4 offset1">
					<h4>$96</h4>
					<table class="table table-bordered offer-tab">
						<tbody>
						<tr>
						<td>Value</td>
						<td>Discount</td>
						<td>Savings</td>
						</tr>
						<tr>
						<td>$120</td>
						<td>20%</td>
						<td>$15</td>
						</tr>
						</tbody>
					</table>
					 <button class="btn span5 pull-right btn-success">Book now</button>
				</div>
			</div>
		</div>
		
		<div class="row-fluid offer_box">
			<div class="offer_box_inner">
				<div class="span3 ">
					<div class="thumbnail">
						<img src="<?php echo base_url();?>images/1.jpg">
						<div class="row-fluid">
							<div class="caption span12">
							<b class="text-left">Sarah wilton</b><br clear="left">
							<small> Hair Stylist </small>
							</div>
						</div>
					</div>
						
				</div>
			<div class="span3 offset1">
				
				<h3>Free <small>with massage</small> <br><b >hair color</b> </h3><br/>
				<p>
					Lorem ipsum dolar sit amit,
					Lorem ipsum dolar sit amit,
				</p>
			</div>
			<div class="span4 offset1">
				<h4>$150</h4>
				<table class="table table-bordered offer-tab">
					<tbody>
					<tr>
					<td>Value</td>
					<td>Discount</td>
					<td>Savings</td>
					</tr>
					<tr>
					<td>$200</td>
					<td>30%</td>
					<td>$60</td>
					</tr>
					</tbody>
				</table>
				 <button class="btn  span5 pull-right btn-success">Book now</button>
			</div>
			</div>
		</div>
 </div>
		</div>	


