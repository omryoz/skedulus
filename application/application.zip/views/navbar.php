<div class="navbar  navbar-inverse">
		  <div class="navbar-inner">
			<a class="btn btn-navbar " data-toggle="collapse" data-target=".menu">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			<div class="nav-collapse collapse menu">			
				<ul class="nav business_navbar">
					<li class="">
						<a href="business_home.php"><center><i class="icon-home"></i><p>Home</p></center></a>
					</li>
					<li class="">
						<a href="my_appointments.php"><center><i class="icon-calendar"></i><p> My Appointments</p>
						</center></a>
					</li>
					<li class="">
						<a href="favourite.php"><center><i class="icon-star"></i><p> Favourite Businesses
						</p></center>
						</a>
					</li>
					<li class=""><a href="offer.php"><center><i class="icon-thumbs-up"></i><p>Special Offers
					</p></center>
						</a>
					</li>
					<li class=""><a href="settings.php"><center><i class="icon-wrench"></i><p>Settings</p>
						</center></a>
					</li>
					
				</ul>
			</div>
		  </div>
		</div>
