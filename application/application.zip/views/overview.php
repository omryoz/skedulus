		
		<div class="row-fluid">
		<h3>Select a date range</h3>
		<div class="span3 ">
			
			
			<table class="table">
        <thead>
          <tr>
            <th>Start Date: <input type="text" class="span12 date_pick" value="" id="dpd1"></th>
            <th>End Date : <input type="text" class="span12 date_pick" value="" id="dpd2"></th>
          </tr>
        </thead>
      </table>
			</div>
		</div>	
			
		<div class="row-fluid">
			<?php include('include/graphbar.htm')?>
			</div>
			<div class="row-fluid">
			<?php include('include/graphline.htm')?>
			</div>
	
		
 	</div>
</div>
